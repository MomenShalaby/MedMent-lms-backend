<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\CourseResource;
use App\Models\Course;
use Illuminate\Http\Request;

class CourseController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return CourseResource::collection(Course::with('user')->paginate());
    }



    /**
     * Display the specified resource.
     */
    public function show(Course $course)
    {
        $course->load('user', 'attendees');
        return new CourseResource($course);
    }



    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $course = Course::create([
            ...$request->validate([
                'course_name' => 'required|max:255',
                'description' => 'required',
            ]),
            'user_id' => 1
        ]);
        return new CourseResource($course);
    }


    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Course $course)
    {
        $course->update([
            ...$request->validate([
                'course_name' => 'sometimes|string|max:255',
                'description' => 'sometimes|nullable|string',
            ]),
        ]);
        return $course;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Course $course)
    {
        $course->delete();
        return response(status: 204);
    }
}
