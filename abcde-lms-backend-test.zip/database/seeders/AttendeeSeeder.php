<?php

namespace Database\Seeders;

use App\Models\Attendee;
use App\Models\Course;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AttendeeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $users = User::all();
        $courses = Course::all();

        foreach ($users as $user) {
            $courseToAttend = $courses->random(rand(1, 3));
            foreach ($courseToAttend as $course) {
                Attendee::create([
                    'user_id' => $user->id,
                    'course_id' => $course->id
                ]);
            }
        }

    }
}
